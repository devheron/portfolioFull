# 🚀 Portfólio Pessoal — Next.js 14

> **PT** · [EN](#english) · [ES](#español)

Portfolio profissional desenvolvido com Next.js 14, TypeScript e Tailwind CSS. Integra GitHub API, DEV.to API, formulário de contato via EmailJS e um **Chat Assistente** com respostas inteligentes.

## ✨ Funcionalidades

- 🌍 **Trilíngue** — Português, Inglês e Espanhol (seletor no navbar)
- 🌙 **Dark / Light mode** com persistência no localStorage
- 🐙 **GitHub API** — repos, commits e seguidores em tempo real
- ✍️ **DEV.to API** — posts automáticos sem token
- 📬 **Formulário de contato** via EmailJS
- 🤖 **Chat Assistente** com respostas estáticas inteligentes
- 📱 **100% responsivo** — mobile first
- ⚡ **Framer Motion** — animações suaves em todo o site

## 🤖 Chat Assistente

O chat responde perguntas sobre stack, disponibilidade, projetos e contato usando **respostas estáticas inteligentes** em PT/EN/ES — sem custo, sem API key extra.

### Ativar Chat com IA (Gemini) — opcional

A integração com **Google Gemini 2.0 Flash** já está implementada, mas comentada. Para ativar quando quiser:

1. Acesse [aistudio.google.com](https://aistudio.google.com) → **Get API Key** → **Create API key in new project** (gratuito)
2. Adicione no `.env.local`:
   ```
   NEXT_PUBLIC_GEMINI_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
3. Em `src/components/ChatWidget.tsx`, substitua a função `send()` pelo bloco `sendAI()` comentado
4. Reinicie: `npm run dev`

> 💡 Cota gratuita: 1.500 req/dia · 15 req/min — suficiente para portfólio.

---

## 🛠️ Stack

| Camada | Tecnologia |
|---|---|
| Framework | Next.js 14 (App Router) |
| Linguagem | TypeScript |
| Estilização | Tailwind CSS + CSS Variables |
| Animações | Framer Motion |
| Email | EmailJS |
| Deploy | Vercel |

---

## ⚡ Instalação

```bash
# 1. Copie os arquivos src/ para o seu projeto
# 2. Instale dependências (se ainda não tiver)
npm install framer-motion @emailjs/browser lucide-react

# 3. Configure variáveis de ambiente
cp .env.local.example .env.local
# Edite .env.local com suas chaves

# 4. Edite seus dados pessoais
# → src/data/portfolio.ts  (nome, email, skills, projetos...)

# 5. Rode
npm run dev
```

---

## 📁 Estrutura

```
src/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   ├── page.tsx
│   └── api/
│       ├── github/route.ts     # proxy server-side
│       ├── contact/route.ts    # EmailJS server-side
│       └── chat/route.ts       # Gemini (para quando ativar)
├── components/
│   ├── Navbar.tsx              # com seletor de idioma
│   ├── Footer.tsx
│   ├── ChatWidget.tsx          # chat estático (Gemini comentado)
│   ├── ThemeProvider.tsx
│   └── sections/
│       ├── Hero.tsx
│       ├── About.tsx
│       ├── Skills.tsx
│       ├── Projects.tsx
│       ├── Posts.tsx
│       └── Contact.tsx
├── data/
│   ├── portfolio.ts            # ← EDITE AQUI seus dados
│   ├── i18n.ts                 # todas as traduções PT/EN/ES
│   ├── LangContext.tsx         # contexto de idioma
│   └── staticChat.ts          # respostas do chat por idioma
├── hooks/
│   ├── useGitHub.ts
│   └── useDevTo.ts
├── lib/
│   ├── github.ts
│   ├── devto.ts
│   └── motion.ts
└── types/index.ts
```

---

## 🔑 Variáveis de Ambiente

```env
# GitHub — github.com/settings/tokens → New token → scope: public_repo
NEXT_PUBLIC_GITHUB_USERNAME=seu-usuario
NEXT_PUBLIC_GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxx
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxx

# DEV.to — sem token, só seu username
NEXT_PUBLIC_DEVTO_USERNAME=seu-usuario

# EmailJS — emailjs.com → Email Services + Email Templates + Account → Public Key
EMAILJS_SERVICE_ID=service_xxxxxxx
EMAILJS_TEMPLATE_ID=template_xxxxxxx
EMAILJS_PUBLIC_KEY=xxxxxxxxxxxxxxxxxxxx

# Gemini (opcional — chat IA) — aistudio.google.com
# NEXT_PUBLIC_GEMINI_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxx
```

> ⚠️ Nunca suba o `.env.local` para o GitHub. O `.gitignore` já o exclui automaticamente.

---

## 🚀 Deploy na Vercel

```bash
# 1. Suba o projeto para o GitHub (sem o .env.local)
git add .
git commit -m "feat: portfolio completo"
git push origin main

# 2. vercel.com → New Project → importar repo
# 3. Environment Variables → adicionar todas as vars do .env.local
# 4. Deploy → URL pública em segundos!
```

A Vercel faz redeploy automático a cada push na branch `main`.

---

## 🎨 Personalizar

Edite **`src/data/portfolio.ts`** — é o único arquivo com seus dados:

- `PERSONAL` — nome, email, redes sociais, localização
- `SKILLS` — suas tecnologias com nível (1=iniciante, 2=confortável, 3=confiante)
- `PROJECTS` — projetos em destaque com links
- `CHAT_SYSTEM_PROMPT` — personalidade do chat AI (para quando ativar)

---

---

## English

# 🚀 Personal Portfolio — Next.js 14

Professional portfolio built with Next.js 14, TypeScript and Tailwind CSS. Integrates GitHub API, DEV.to API, EmailJS contact form and a **Chat Assistant** with intelligent static responses.

## ✨ Features

- 🌍 **Trilingual** — Portuguese, English and Spanish (navbar selector)
- 🌙 **Dark / Light mode** with localStorage persistence
- 🐙 **GitHub API** — live repos, commits and followers
- ✍️ **DEV.to API** — automatic posts, no token needed
- 📬 **Contact form** via EmailJS
- 🤖 **Chat Assistant** with smart static responses
- 📱 **Fully responsive** — mobile first
- ⚡ **Framer Motion** — smooth animations throughout

## 🤖 Chat Assistant

The chat answers questions about stack, availability, projects and contact using **smart static responses** in PT/EN/ES — no cost, no extra API key.

### Enable AI Chat (Gemini) — optional

The **Google Gemini 2.0 Flash** integration is already implemented but commented out. To activate whenever you're ready:

1. Go to [aistudio.google.com](https://aistudio.google.com) → **Get API Key** → **Create API key in new project** (free)
2. Add to `.env.local`:
   ```
   NEXT_PUBLIC_GEMINI_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
3. In `src/components/ChatWidget.tsx`, replace the `send()` function with the commented `sendAI()` block
4. Restart: `npm run dev`

> 💡 Free quota: 1,500 req/day · 15 req/min — more than enough for a portfolio.

---

## ⚡ Setup

```bash
npm install framer-motion @emailjs/browser lucide-react
cp .env.local.example .env.local
# Fill in your keys, then edit src/data/portfolio.ts with your info
npm run dev
```

---

---

## Español

# 🚀 Portafolio Personal — Next.js 14

Portafolio profesional construido con Next.js 14, TypeScript y Tailwind CSS. Integra GitHub API, DEV.to API, formulario de contacto vía EmailJS y un **Asistente de Chat** con respuestas estáticas inteligentes.

## ✨ Características

- 🌍 **Trilingüe** — Portugués, Inglés y Español (selector en el navbar)
- 🌙 **Modo oscuro / claro** con persistencia en localStorage
- 🐙 **GitHub API** — repos, commits y seguidores en tiempo real
- ✍️ **DEV.to API** — posts automáticos sin token
- 📬 **Formulario de contacto** vía EmailJS
- 🤖 **Asistente de Chat** con respuestas estáticas inteligentes
- 📱 **100% responsivo** — mobile first
- ⚡ **Framer Motion** — animaciones suaves en todo el sitio

## 🤖 Asistente de Chat

El chat responde preguntas sobre stack, disponibilidad, proyectos y contacto usando **respuestas estáticas inteligentes** en PT/EN/ES — sin costo, sin API key adicional.

### Activar Chat con IA (Gemini) — opcional

La integración con **Google Gemini 2.0 Flash** ya está implementada pero comentada. Para activar cuando quieras:

1. Ve a [aistudio.google.com](https://aistudio.google.com) → **Get API Key** → **Create API key in new project** (gratuito)
2. Agrega en `.env.local`:
   ```
   NEXT_PUBLIC_GEMINI_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
3. En `src/components/ChatWidget.tsx`, reemplaza la función `send()` con el bloque `sendAI()` comentado
4. Reinicia: `npm run dev`

> 💡 Cuota gratuita: 1.500 req/día · 15 req/min — suficiente para un portafolio.

---

## ⚡ Instalación

```bash
npm install framer-motion @emailjs/browser lucide-react
cp .env.local.example .env.local
# Completa tus claves, luego edita src/data/portfolio.ts con tus datos
npm run dev
```
